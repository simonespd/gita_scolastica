<?php
class ItineraryController {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Mostra il form per personalizzare l’itinerario
    public function customize() {
        // Recupera le mete e i tour disponibili
        // Assicurati di avere i modelli per le mete e i tour
        $meteModel = new MeteModel($this->pdo);
        $tourModel = new TourModel($this->pdo);
        
        $mete = $meteModel->getAllMete();
        $tours = $tourModel->getAllTours();

        require 'View/itinerary_customize.php';
    }

    // Salva l’itinerario personalizzato
    public function save() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Leggi i tour selezionati
            $selectedTours = $_POST['tours'] ?? [];
            $userId = $_SESSION['user_id'] ?? null;

            if (empty($selectedTours)) {
                echo "<script>alert('Devi selezionare almeno un tour!'); window.history.back();</script>";
                return;
            }

            // Sanificazione dei dati
            $selectedTours = array_map('intval', $selectedTours); // Assicurati che i tour siano numerici

            // Aggiungi la logica per creare un itinerario e salvare nel database
            try {
                $this->saveItinerary($userId, $selectedTours);
                echo "<script>alert('Itinerario salvato con successo!'); window.location.href='index.php';</script>";
            } catch (Exception $e) {
                echo "<script>alert('Si è verificato un errore durante il salvataggio dell\'itinerario.'); window.location.href='index.php';</script>";
            }
        }
    }

    private function saveItinerary($userId, $selectedTours) {
        // Crea l'itinerario nel database
        $stmt = $this->pdo->prepare("INSERT INTO itineraries (user_id) VALUES (:user_id)");
        $stmt->execute([':user_id' => $userId]);

        // Recupera l'ID dell'itinerario appena creato
        $itineraryId = $this->pdo->lastInsertId();

        // Salva i tour associati all'itinerario
        foreach ($selectedTours as $tourId) {
            $stmt = $this->pdo->prepare("INSERT INTO itinerary_tours (itinerary_id, tour_id) VALUES (:itinerary_id, :tour_id)");
            $stmt->execute([':itinerary_id' => $itineraryId, ':tour_id' => $tourId]);
        }
    }
}
?>
