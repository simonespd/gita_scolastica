<?php
require_once 'Model/ReviewModel.php';

class ReviewController {
    private $reviewModel;

    public function __construct($pdo) {
        $this->reviewModel = new ReviewModel($pdo);
    }

    // Visualizza le recensioni per una meta e il form per aggiungerne una
    public function index($metaId) {
        // Recupera le recensioni dalla meta
        $reviews = $this->reviewModel->getReviewsByMeta($metaId);
        require 'View/review_index.php';
    }

    // Salva una nuova recensione
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $metaId  = $_POST['meta_id'] ?? null;
            $userId  = $_SESSION['user_id'] ?? null;
            $rating  = $_POST['rating'] ?? null;
            $comment = $_POST['comment'] ?? '';

            // Controllo se tutti i campi obbligatori sono stati inviati
            if (!$metaId || !$userId || !$rating) {
                echo "<script>alert('Tutti i campi obbligatori devono essere compilati.'); window.history.back();</script>";
                return;
            }

            // Validazione del rating (ad esempio tra 1 e 5)
            if (!is_numeric($rating) || $rating < 1 || $rating > 5) {
                echo "<script>alert('Il rating deve essere un numero tra 1 e 5.'); window.history.back();</script>";
                return;
            }

            // Salva la recensione
            $this->reviewModel->createReview($metaId, $userId, $rating, $comment);
            echo "<script>alert('Recensione salvata con successo!'); window.location.href='index.php?url=review-index&meta_id=" . $metaId . "';</script>";
        }
    }
}
?>
