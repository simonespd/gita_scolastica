<?php
require_once 'Model/UserModel.php';

class UserController {
    private $userModel;

    public function __construct()
    {
        global $pdo;
        $this->userModel = new UserModel($pdo);
    }

    public function register()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $cognome  = trim($_POST['cognome'] ?? '');
            $nome     = trim($_POST['nome'] ?? '');
            $email    = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';

            // Validazione dell'input
            if (empty($cognome) || empty($nome) || empty($email) || empty($password)) {
                echo "<script>alert('Tutti i campi sono obbligatori.'); window.history.back();</script>";
                return;
            }

            // Verifica se la email è già registrata
            if ($this->userModel->isEmailTaken($email)) {
                echo "<script>alert('Email già registrata.'); window.history.back();</script>";
                return;
            }

            // Registrazione utente
            $this->userModel->register($cognome, $nome, $email, $password);
            echo "<script>alert('Registrazione avvenuta con successo'); window.location.href='index.php';</script>";
        } else {
            require 'View/register.php';
        }
    }

    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email    = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';

            // Validazione dell'input
            if (empty($email) || empty($password)) {
                echo "<script>alert('Email e password sono obbligatori.'); window.history.back();</script>";
                return;
            }

            $userId = $this->userModel->checkUser($email, $password);

            if ($userId) {
                $_SESSION['user_id'] = $userId; // Salva ID utente in sessione
                echo "<script>alert('Login effettuato con successo'); window.location.href='index.php';</script>";
            } else {
                echo "<script>alert('Credenziali non valide'); window.history.back();</script>";
            }
        } else {
            require 'View/login.php';
        }
    }
}
