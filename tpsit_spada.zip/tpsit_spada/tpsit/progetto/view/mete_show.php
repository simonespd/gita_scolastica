<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8">
  <title>Dettagli Meta</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .card h3 {
      color: #0d6efd;
    }
    .section-title {
      border-bottom: 2px solid #dee2e6;
      padding-bottom: 5px;
      margin-bottom: 15px;
    }
  </style>
</head>
<body class="bg-light">
<div class="container py-5">
  <?php if(isset($meta) && $meta): ?>
    <h2 class="section-title">Dettagli Meta</h2>
    <div class="card mb-4 shadow-sm p-4">
      <h3><?php echo htmlspecialchars($meta['nome']); ?></h3>
      <p><strong>Descrizione:</strong><br><?php echo nl2br(htmlspecialchars($meta['descrizione'])); ?></p>
      <p><strong>Data Gita:</strong> <?php echo htmlspecialchars($meta['data_gita']); ?></p>
      <p><strong>Costo Base:</strong> € <?php echo htmlspecialchars($meta['costo']); ?></p>
      <p><strong>Max Partecipanti:</strong> <?php echo htmlspecialchars($meta['numero_partecipanti']); ?></p>
    </div>

    <!-- Azioni -->
    <div class="mb-4 d-flex flex-wrap gap-2">
      <a href="index.php?url=tour-index&meta_id=<?php echo $meta['id']; ?>" class="btn btn-info">Visualizza Tour</a>
      <?php if(isset($_SESSION['user_id']) && $_SESSION['user_id'] == $meta['user_id']): ?>
        <a href="index.php?url=tour-create&meta_id=<?php echo $meta['id']; ?>" class="btn btn-primary">Aggiungi Tour</a>
      <?php endif; ?>
      <a href="index.php?url=review-index&meta_id=<?php echo $meta['id']; ?>" class="btn btn-secondary">Vedi Recensioni</a>
    </div>

    <!-- Tour -->
    <h4 class="section-title">Tour Associati</h4>
    <?php if(!empty($tours)): ?>
      <div class="table-responsive">
        <table class="table table-striped table-bordered align-middle">
          <thead class="table-light">
            <tr>
              <th>Nome Tour</th>
              <th>Descrizione</th>
              <th>Durata (giorni)</th>
              <th>Costo aggiuntivo</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($tours as $tour): ?>
              <tr>
                <td><?php echo htmlspecialchars($tour['nome']); ?></td>
                <td><?php echo htmlspecialchars($tour['descrizione']); ?></td>
                <td><?php echo htmlspecialchars($tour['durata']); ?></td>
                <td>€ <?php echo htmlspecialchars($tour['costo_aggiuntivo']); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <p class="text-muted">Nessun tour associato a questa meta.</p>
    <?php endif; ?>

    <!-- Prezzo Totale -->
    <?php if(isset($_SESSION['user_id'])): ?>
      <div class="alert alert-info mt-4">
        <strong>Prezzo Totale:</strong> € <?php echo number_format($totalPrice, 2, ',', '.'); ?>
      </div>
    <?php endif; ?>

    <!-- Navigazione -->
    <div class="mt-4 d-flex gap-2 flex-wrap">
      <a href="index.php?url=mete" class="btn btn-outline-secondary">Torna all'elenco delle mete</a>
      <a href="index.php" class="btn btn-outline-dark">Torna alla Home</a>
    </div>
  <?php else: ?>
    <div class="alert alert-danger">Meta non trovata.</div>
    <a href="index.php?url=mete" class="btn btn-secondary">Torna all'elenco delle mete</a>
  <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
