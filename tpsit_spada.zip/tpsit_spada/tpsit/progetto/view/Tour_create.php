<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Crea Nuovo Tour</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f4f8;
        }
        .form-wrapper {
            max-width: 650px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.05);
            padding: 30px;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <h2 class="text-center mb-4">➕ Crea un Nuovo Tour</h2>

    <div class="form-wrapper">
        <form method="post" action="index.php?url=tour-store&meta_id=<?php echo $_GET['meta_id']; ?>">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome del Tour</label>
                <input type="text" name="nome" id="nome" class="form-control" placeholder="Es. Tour delle Dolomiti" required>
            </div>

            <div class="mb-3">
                <label for="descrizione" class="form-label">Descrizione</label>
                <textarea name="descrizione" id="descrizione" class="form-control" rows="3" placeholder="Scrivi una breve descrizione del tour..."></textarea>
            </div>

            <div class="mb-3">
                <label for="durata" class="form-label">Durata (in giorni)</label>
                <input type="number" name="durata" id="durata" class="form-control" min="1" placeholder="Durata prevista" required>
            </div>

            <div class="mb-4">
                <label for="costo_aggiuntivo" class="form-label">Costo Aggiuntivo (€)</label>
                <input type="number" step="0.01" name="costo_aggiuntivo" id="costo_aggiuntivo" class="form-control" value="0">
            </div>

            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-success">✅ Crea Tour</button>
                <a href="index.php?url=tour-index&meta_id=<?php echo $_GET['meta_id']; ?>" class="btn btn-outline-secondary">↩ Torna Indietro</a>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
