<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8">
  <title>Elenco Mete</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .table td, .table th {
      vertical-align: middle;
    }
    .btn-sm {
      margin-bottom: 4px;
    }
  </style>
</head>
<body class="bg-light">
<div class="container py-5">
    <h2 class="mb-4">Elenco Mete</h2>
    
    <div class="mb-3 d-flex justify-content-between align-items-center">
        <a href="?url=mete-create" class="btn btn-primary">➕ Aggiungi Nuova Meta</a>
    </div>
    
    <div class="table-responsive">
      <table class="table table-striped table-hover align-middle">
        <thead class="table-light">
          <tr>
              <th>Nome</th>
              <th>Descrizione</th>
              <th>Data</th>
              <th>Costo</th>
              <th>Max Partecipanti</th>
              <th>Azioni</th>
              <th>Recensioni</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($mete)): ?>
              <?php foreach ($mete as $m): ?>
                  <tr>
                      <td><strong><?php echo htmlspecialchars($m['nome']); ?></strong></td>
                      <td><?php echo htmlspecialchars($m['descrizione']); ?></td>
                      <td><?php echo htmlspecialchars($m['data_gita']); ?></td>
                      <td>€ <?php echo number_format($m['costo'], 2, ',', '.'); ?></td>
                      <td><?php echo htmlspecialchars($m['numero_partecipanti']); ?></td>
                      <td>
                          <div class="d-flex flex-column flex-md-row gap-1">
                              <a href="?url=mete-show&id=<?php echo $m['id']; ?>" class="btn btn-info btn-sm">Dettagli</a>
                              <?php if ($m['user_id'] == $_SESSION['user_id']): ?>
                                  <a href="?url=mete-edit&id=<?php echo $m['id']; ?>" class="btn btn-warning btn-sm">Modifica</a>
                                  <a href="?url=mete-delete&id=<?php echo $m['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Sei sicuro di voler eliminare questa meta?')">Elimina</a>
                              <?php else: ?>
                                  <?php if (!($m['is_user_joined'] ?? false)): ?>
                                      <a href="?url=mete-join&id=<?php echo $m['id']; ?>" class="btn btn-success btn-sm">Iscriviti</a>
                                  <?php else: ?>
                                      <span class="badge bg-secondary align-self-center">Già iscritto</span>
                                  <?php endif; ?>
                              <?php endif; ?>
                          </div>
                      </td>
                      <td>
                          <a href="index.php?url=review-index&meta_id=<?php echo $m['id']; ?>" class="btn btn-outline-info btn-sm">Recensioni</a>
                      </td>
                  </tr>
              <?php endforeach; ?>
          <?php else: ?>
              <tr><td colspan="7" class="text-center text-muted">Nessuna meta trovata.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <a href="index.php" class="btn btn-outline-secondary mt-3">🏠 Torna alla Home</a>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
