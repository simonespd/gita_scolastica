<?php ?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Recensioni sulla Meta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8fafc;
        }
        .review-card {
            border-left: 6px solid #0d6efd;
            background-color: #ffffff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }
        .review-form {
            background-color: #ffffff;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
        }
    </style>
</head>
<body>
<div class="container py-5">
    <h2 class="mb-4 text-primary text-center">🌍 Recensioni sulla Meta</h2>

    <?php if (!empty($reviews)): ?>
        <div class="mb-4">
            <?php foreach ($reviews as $r): ?>
                <div class="review-card mb-3">
                    <h5 class="mb-1">
                        <?php echo htmlspecialchars($r['nome'] . ' ' . $r['cognome']); ?>
                        <span class="badge bg-warning text-dark ms-2">★ <?php echo htmlspecialchars($r['rating']); ?></span>
                    </h5>
                    <p class="mb-2"><?php echo nl2br(htmlspecialchars($r['comment'])); ?></p>
                    <small class="text-muted">🕒 <?php echo htmlspecialchars($r['created_at']); ?></small>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info">Nessuna recensione disponibile per questa meta.</div>
    <?php endif; ?>

    <h4 class="mt-5 mb-3 text-success">✍️ Lascia una Recensione</h4>
    <form method="post" action="index.php?url=review-store" class="review-form">
        <input type="hidden" name="meta_id" value="<?php echo $_GET['meta_id']; ?>">
        
        <div class="mb-3">
            <label for="rating" class="form-label">Valutazione (da 1 a 5)</label>
            <input type="number" name="rating" id="rating" class="form-control" min="1" max="5" required>
        </div>

        <div class="mb-4">
            <label for="comment" class="form-label">Commento</label>
            <textarea name="comment" id="comment" class="form-control" rows="4" placeholder="Scrivi qui la tua esperienza..."></textarea>
        </div>

        <div class="d-flex justify-content-between">
            <button type="submit" class="btn btn-success">📤 Invia Recensione</button>
            <a href="?url=mete" class="btn btn-outline-secondary">↩ Torna all'elenco</a>
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
