<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Modifica Tour</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #eef2f7;
        }
        .form-card {
            border-radius: 12px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.1);
            background-color: #fff;
        }
    </style>
</head>
<body>
<div class="container py-5">
    <h2 class="mb-4 text-center">Modifica Tour</h2>

    <?php if ($tour): ?>
        <form method="post" action="index.php?url=tour-update" class="form-card p-4 mx-auto" style="max-width: 600px;">
            <input type="hidden" name="id" value="<?php echo $tour['id']; ?>">
            <input type="hidden" name="meta_id" value="<?php echo $tour['meta_id']; ?>">

            <div class="mb-3">
                <label for="nome" class="form-label">Nome del Tour</label>
                <input type="text" name="nome" id="nome" class="form-control" value="<?php echo htmlspecialchars($tour['nome']); ?>" required>
            </div>

            <div class="mb-3">
                <label for="descrizione" class="form-label">Descrizione</label>
                <textarea name="descrizione" id="descrizione" class="form-control" rows="3" placeholder="Inserisci una descrizione..."><?php echo htmlspecialchars($tour['descrizione']); ?></textarea>
            </div>

            <div class="mb-3">
                <label for="durata" class="form-label">Durata (giorni)</label>
                <input type="number" name="durata" id="durata" class="form-control" value="<?php echo htmlspecialchars($tour['durata']); ?>" min="1" required>
            </div>

            <div class="mb-4">
                <label for="costo_aggiuntivo" class="form-label">Costo aggiuntivo (€)</label>
                <input type="number" step="0.01" name="costo_aggiuntivo" id="costo_aggiuntivo" class="form-control" value="<?php echo htmlspecialchars($tour['costo_aggiuntivo']); ?>">
            </div>

            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-success">
                    💾 Salva modifiche
                </button>
                <a href="index.php?url=tour-index&meta_id=<?php echo $tour['meta_id']; ?>" class="btn btn-outline-secondary">
                    ⬅ Annulla
                </a>
            </div>
        </form>
    <?php else: ?>
        <div class="alert alert-danger text-center">❌ Tour non trovato.</div>
        <div class="text-center mt-3">
            <a href="index.php?url=tour-index&meta_id=<?php echo $_GET['meta_id']; ?>" class="btn btn-outline-secondary">🔙 Torna ai Tour</a>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
