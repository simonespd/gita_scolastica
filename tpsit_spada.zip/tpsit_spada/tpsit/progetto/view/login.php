<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .form-label {
      font-weight: bold;
    }
    .form-control {
      border-radius: 10px;
    }
    .btn {
      border-radius: 5px;
    }
  </style>
</head>
<body class="bg-light">
<div class="container mt-5">
    <h2 class="mb-4">Login</h2>

    <!-- Messaggio di errore, se presente -->
    <?php if (isset($login_error) && $login_error): ?>
        <div class="alert alert-danger" role="alert">
            <strong>Errore:</strong> Credenziali non valide. Riprova.
        </div>
    <?php endif; ?>

    <form method="post" action="?url=login" class="card p-4 shadow-sm">
        <div class="mb-3">
            <label for="email" class="form-label">E-mail</label>
            <input type="email" name="email" id="email" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" name="password" id="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Accedi</button>
    </form>

    <p class="mt-3">
        <a href="?url=register">Non hai un account? Registrati</a>
    </p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
