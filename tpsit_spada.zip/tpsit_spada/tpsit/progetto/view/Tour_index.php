<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Tour Disponibili</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f2f4f8;
        }
        .tour-card {
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .badge-promo {
            background-color: #ffc107;
            color: #000;
        }
    </style>
</head>
<body>
<div class="container my-5">
    <h2 class="mb-4 text-center">Elenco dei Tour</h2>

    <?php if (!empty($tours)): ?>
        <div class="row row-cols-1 row-cols-md-2 g-4">
            <?php foreach($tours as $tour): 
                $id = htmlspecialchars($tour['id']);
                $nome = htmlspecialchars($tour['nome']);
                $descrizione = htmlspecialchars($tour['descrizione'] ?? 'Nessuna descrizione.');
                $costo = $tour['costo_aggiuntivo'];
                $hasPromo = isset($tour['promotion']) && $tour['promotion']['discount'] > 0;
                $sconto = $hasPromo ? $tour['promotion']['discount'] : 0;
                $costoFinale = $hasPromo ? $costo - ($costo * $sconto / 100) : $costo;
            ?>
            <div class="col">
                <div class="card tour-card h-100">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $nome; ?></h5>
                        <p class="card-text text-muted"><?php echo $descrizione; ?></p>
                        <p class="mb-1">
                            <strong>Prezzo:</strong>
                            <?php if ($hasPromo): ?>
                                <span class="text-danger fw-bold">
                                    <del>€<?php echo number_format($costo, 2); ?></del> €<?php echo number_format($costoFinale, 2); ?>
                                </span>
                                <span class="badge badge-promo ms-2"><?php echo $sconto; ?>% OFF</span>
                            <?php else: ?>
                                <span class="fw-semibold">€<?php echo number_format($costo, 2); ?></span>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="card-footer bg-white border-top-0 d-flex justify-content-between">
                        <a href="index.php?url=tour-edit&id=<?php echo $id; ?>" class="btn btn-outline-primary btn-sm">Modifica</a>
                        <a href="index.php?url=tour-delete&id=<?php echo $id; ?>" class="btn btn-outline-danger btn-sm">Elimina</a>
                        <a href="index.php?url=tour-join&id=<?php echo $id; ?>" class="btn btn-outline-success btn-sm">Partecipa</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-warning text-center" role="alert">
            Nessun tour disponibile al momento.
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
