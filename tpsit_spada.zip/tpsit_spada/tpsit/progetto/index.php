<?php
session_start();

require_once 'config/db.php';
require_once 'Controller/UserController.php';
require_once 'Controller/MeteController.php';
require_once 'Controller/TourController.php';
require_once 'Controller/ReviewController.php';
require_once 'Controller/ItineraryController.php';

function requireLogin() {
    if (empty($_SESSION['user_id'])) {
        echo "<script>alert('Effettua il login per continuare.'); window.location.href='index.php?url=login';</script>";
        exit;
    }
}

// Istanza dei controller
$controllers = [
    'user' => new UserController($pdo),
    'mete' => new MeteController($pdo),
    'tour' => new TourController($pdo),
    'review' => new ReviewController($pdo),
    'itinerary' => new ItineraryController($pdo)
];

$url = $_GET['url'] ?? 'home';

function route($url, $controllers) {
    switch ($url) {
        // UTENTE
        case 'register':
            return $controllers['user']->register();
        case 'login':
            return $controllers['user']->login();

        // METE
        case 'mete':
            requireLogin();
            return $controllers['mete']->index();
        case 'mete-create':
            requireLogin();
            return $controllers['mete']->create();
        case 'mete-store':
            requireLogin();
            return $controllers['mete']->store();
        case 'mete-edit':
            requireLogin();
            return $controllers['mete']->edit($_GET['id'] ?? null);
        case 'mete-update':
            requireLogin();
            return $controllers['mete']->update();
        case 'mete-delete':
            requireLogin();
            return $controllers['mete']->delete($_GET['id'] ?? null);
        case 'mete-join':
            requireLogin();
            return $controllers['mete']->join($_GET['id'] ?? null);
        case 'mete-show':
            requireLogin();
            return $controllers['mete']->show($_GET['id'] ?? null);

        // TOUR
        case 'tour-index':
            requireLogin();
            return $controllers['tour']->index($_GET['meta_id'] ?? null);
        case 'tour-create':
            requireLogin();
            return $controllers['tour']->create($_GET['meta_id'] ?? null);
        case 'tour-store':
            requireLogin();
            return $controllers['tour']->store($_GET['meta_id'] ?? null);
        case 'tour-edit':
            requireLogin();
            return $controllers['tour']->edit($_GET['id'] ?? null);
        case 'tour-update':
            requireLogin();
            return $controllers['tour']->update();
        case 'tour-delete':
            requireLogin();
            return $controllers['tour']->delete($_GET['id'] ?? null, $_GET['meta_id'] ?? null);
        case 'tour-join':
            requireLogin();
            return $controllers['tour']->join($_GET['id'] ?? null);

        // RECENSIONI
        case 'review-index':
            requireLogin();
            return $controllers['review']->index($_GET['meta_id'] ?? null);
        case 'review-store':
            requireLogin();
            return $controllers['review']->store();

        // ITINERARI
        case 'itinerary-customize':
            requireLogin();
            return $controllers['itinerary']->customize();
        case 'itinerary-save':
            requireLogin();
            return $controllers['itinerary']->save();

        // HOME DEFAULT
        default:
            renderHomePage();
            break;
    }
}

function renderHomePage() {
    ?>
    <!DOCTYPE html>
    <html lang="it">
    <head>
        <meta charset="UTF-8">
        <title>Gestione Gite</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body {
                background: #f8f9fa;
            }
            .welcome-card {
                max-width: 500px;
                margin: 100px auto;
                padding: 2rem;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
                border-radius: 15px;
                background: white;
            }
        </style>
    </head>
    <body>
        <div class="welcome-card text-center">
            <h2 class="mb-4">Benvenuto in Gestione Gite</h2>
            <div class="d-grid gap-2">
                <a class="btn btn-outline-primary" href="?url=register">Registrati</a>
                <a class="btn btn-outline-success" href="?url=login">Accedi</a>
                <a class="btn btn-outline-secondary" href="?url=mete">Esplora le Mete</a>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    <?php
}

// Esegui la route
route($url, $controllers);
?>
