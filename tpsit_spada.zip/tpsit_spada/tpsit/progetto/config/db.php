<?php
// Impostazioni connessione al database
define('DB_HOST', 'localhost');
define('DB_NAME', 'gite_scolastiche');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

try {
    // Creazione della connessione PDO con modalità di errore tramite eccezioni
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASSWORD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Attiva la modalità di errore tramite eccezione
} catch (PDOException $e) {
    // Log dell'errore in un file di log
    error_log("Errore di connessione al database: " . $e->getMessage(), 3, 'error_log.txt');
    exit('Connessione fallita. Si è verificato un errore.'); // Messaggio generico per non rivelare dettagli sensibili
}
?>
