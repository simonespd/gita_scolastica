<?php
class MeteModel {
    private $pdo;

    public function __construct($pdo)
    {
        $this->pdo = $pdo;
    }

    public function getAllMete()
    {
        try {
            $stmt = $this->pdo->query("SELECT * FROM mete ORDER BY data_gita ASC");
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return ['error' => 'Errore nel recupero delle mete: ' . $e->getMessage()];
        }
    }

    public function createMeta($nome, $desc, $data, $costo, $maxPartecipanti, $userId)
    {
        // Validazioni
        if ($maxPartecipanti <= 0 || $costo < 0) {
            return ['error' => 'Numero partecipanti e costo devono essere valori validi.'];
        }

        try {
            $sql = "INSERT INTO mete (nome, descrizione, data_gita, costo, numero_partecipanti, user_id)
                    VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$nome, $desc, $data, $costo, $maxPartecipanti, $userId]);
            return ['success' => 'Meta creata con successo.'];
        } catch (Exception $e) {
            return ['error' => 'Errore durante la creazione della meta: ' . $e->getMessage()];
        }
    }

    public function getMetaById($id)
    {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM mete WHERE id = ?");
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return ['error' => 'Errore nel recupero della meta: ' . $e->getMessage()];
        }
    }

    public function updateMeta($id, $nome, $desc, $data, $costo, $maxPartecipanti)
    {
        try {
            $sql = "UPDATE mete 
                    SET nome=?, descrizione=?, data_gita=?, costo=?, numero_partecipanti=? 
                    WHERE id=?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$nome, $desc, $data, $costo, $maxPartecipanti, $id]);
            return ['success' => 'Meta aggiornata con successo.'];
        } catch (Exception $e) {
            return ['error' => 'Errore durante l\'aggiornamento della meta: ' . $e->getMessage()];
        }
    }

    public function deleteMeta($id)
    {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM mete WHERE id = ?");
            $stmt->execute([$id]);
            return ['success' => 'Meta eliminata con successo.'];
        } catch (Exception $e) {
            return ['error' => 'Errore durante l\'eliminazione della meta: ' . $e->getMessage()];
        }
    }

    public function isOwner($metaId, $userId)
    {
        try {
            $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM mete WHERE id = ? AND user_id = ?");
            $stmt->execute([$metaId, $userId]);
            return $stmt->fetchColumn() > 0;
        } catch (Exception $e) {
            return false; // In caso di errore si assume che l'utente non sia il proprietario
        }
    }

    public function countPartecipanti($metaId)
    {
        try {
            $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM adesioni WHERE meta_id = ?");
            $stmt->execute([$metaId]);
            return $stmt->fetchColumn();
        } catch (Exception $e) {
            return 0; // In caso di errore si ritorna 0 partecipanti
        }
    }

    public function joinMeta($metaId, $userId)
    {
        // Controlla se l'utente è già iscritto
        try {
            $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM adesioni WHERE meta_id = ? AND user_id = ?");
            $stmt->execute([$metaId, $userId]);
            if ($stmt->fetchColumn() > 0) {
                return ['error' => 'Già iscritto alla meta.'];
            }

            // Recupera i dati della meta per verificare il limite
            $meta = $this->getMetaById($metaId);
            $iscritti = $this->countPartecipanti($metaId);

            if ($iscritti < $meta['numero_partecipanti']) {
                $stmt = $this->pdo->prepare("INSERT INTO adesioni (meta_id, user_id) VALUES (?, ?)");
                if ($stmt->execute([$metaId, $userId])) {
                    return ['success' => 'Iscrizione alla meta avvenuta con successo.'];
                }
            }

            return ['error' => 'Numero massimo di partecipanti raggiunto o errore di iscrizione.'];
        } catch (Exception $e) {
            return ['error' => 'Errore durante l\'iscrizione alla meta: ' . $e->getMessage()];
        }
    }

    public function getToursByMetaId($metaId) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM tours WHERE meta_id = :meta_id");
            $stmt->execute(['meta_id' => $metaId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return ['error' => 'Errore nel recupero dei tour: ' . $e->getMessage()];
        }
    }

    public function getTotalPrice($metaId, $userId)
    {
        try {
            // Recupera il costo base della meta
            $stmt = $this->pdo->prepare("SELECT costo FROM mete WHERE id = ?");
            $stmt->execute([$metaId]);
            $baseCost = (float)$stmt->fetchColumn();

            // Somma i costi aggiuntivi dei tour a cui l'utente è iscritto per quella meta
            $stmt2 = $this->pdo->prepare("
                SELECT SUM(t.costo_aggiuntivo) 
                FROM tours t 
                JOIN tour_adesioni ta ON t.id = ta.tour_id 
                WHERE ta.user_id = ? AND t.meta_id = ?
            ");
            $stmt2->execute([$userId, $metaId]);
            $tourCost = (float)$stmt2->fetchColumn();
            
            return $baseCost + $tourCost;
        } catch (Exception $e) {
            return ['error' => 'Errore nel calcolo del prezzo totale: ' . $e->getMessage()];
        }
    }
}
?>
