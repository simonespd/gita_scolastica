<?php
class ReviewModel {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Salva una recensione per una meta
    public function createReview($metaId, $userId, $rating, $comment) {
        try {
            // Controllo per la validità del rating (ad esempio, deve essere tra 1 e 5)
            if ($rating < 1 || $rating > 5) {
                return ['error' => 'Il rating deve essere tra 1 e 5.'];
            }

            // Prepara la query per inserire la recensione
            $sql = "INSERT INTO reviews (meta_id, user_id, rating, comment, created_at) VALUES (?, ?, ?, ?, NOW())";
            $stmt = $this->pdo->prepare($sql);
            if ($stmt->execute([$metaId, $userId, $rating, $comment])) {
                return ['success' => 'Recensione salvata con successo.'];
            } else {
                return ['error' => 'Impossibile salvare la recensione.'];
            }
        } catch (Exception $e) {
            // Gestione degli errori
            return ['error' => 'Errore durante il salvataggio della recensione: ' . $e->getMessage()];
        }
    }

    // Recupera le recensioni per una meta
    public function getReviewsByMeta($metaId) {
        try {
            $sql = "SELECT r.*, u.nome, u.cognome 
                    FROM reviews r 
                    JOIN user u ON r.user_id = u.id 
                    WHERE r.meta_id = ? 
                    ORDER BY r.created_at DESC";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$metaId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            // Gestione degli errori
            return ['error' => 'Errore durante il recupero delle recensioni: ' . $e->getMessage()];
        }
    }
}
?>
