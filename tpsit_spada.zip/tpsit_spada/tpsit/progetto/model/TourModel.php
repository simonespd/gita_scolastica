<?php
class TourModel {
    private $pdo;

    public function __construct($pdo)
    {
        $this->pdo = $pdo;
    }

    // Restituisce i tour per una determinata meta
    public function getToursByMeta($metaId)
    {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM tours WHERE meta_id = ? ORDER BY nome ASC");
            $stmt->execute([$metaId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            // Gestione dell'errore
            return ['error' => 'Impossibile recuperare i tour: ' . $e->getMessage()];
        }
    }

    // Crea un nuovo tour associato a una meta
    public function createTour($metaId, $nome, $descrizione, $durata, $costo_aggiuntivo)
    {
        // Verifica se la meta esiste prima di inserire il tour
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM mete WHERE id = ?");
        $stmt->execute([$metaId]);
        if ($stmt->fetchColumn() == 0) {
            return ['error' => 'Meta non trovata.'];
        }

        try {
            $sql = "INSERT INTO tours (meta_id, nome, descrizione, durata, costo_aggiuntivo)
                    VALUES (?, ?, ?, ?, ?)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$metaId, $nome, $descrizione, $durata, $costo_aggiuntivo]);
            return ['success' => 'Tour creato con successo.'];
        } catch (Exception $e) {
            return ['error' => 'Impossibile creare il tour: ' . $e->getMessage()];
        }
    }

    // Recupera un tour passando il suo id
    public function getTourById($id)
    {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM tours WHERE id = ?");
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return ['error' => 'Impossibile recuperare il tour: ' . $e->getMessage()];
        }
    }

    // Aggiorna i dati di un tour
    public function updateTour($id, $nome, $descrizione, $durata, $costo_aggiuntivo)
    {
        try {
            $sql = "UPDATE tours 
                    SET nome = ?, descrizione = ?, durata = ?, costo_aggiuntivo = ? 
                    WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$nome, $descrizione, $durata, $costo_aggiuntivo, $id]);
            return ['success' => 'Tour aggiornato con successo.'];
        } catch (Exception $e) {
            return ['error' => 'Impossibile aggiornare il tour: ' . $e->getMessage()];
        }
    }

    // Elimina un tour
    public function deleteTour($id)
    {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM tours WHERE id = ?");
            $stmt->execute([$id]);
            return ['success' => 'Tour eliminato con successo.'];
        } catch (Exception $e) {
            return ['error' => 'Impossibile eliminare il tour: ' . $e->getMessage()];
        }
    }

    // Metodo per verificare se l'utente è già iscritto a un tour
    public function isUserJoined($tourId, $userId)
    {
        try {
            $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM tour_adesioni WHERE tour_id = ? AND user_id = ?");
            $stmt->execute([$tourId, $userId]);
            return $stmt->fetchColumn() > 0;
        } catch (Exception $e) {
            return ['error' => 'Errore nel verificare l\'adesione: ' . $e->getMessage()];
        }
    }
    
    // Metodo per iscrivere un utente a un tour
    public function joinTour($tourId, $userId)
    {
        // Verifica che l'utente non sia già iscritto
        if ($this->isUserJoined($tourId, $userId)) {
            return ['error' => 'Utente già iscritto al tour.'];
        }

        try {
            $stmt = $this->pdo->prepare("INSERT INTO tour_adesioni (tour_id, user_id) VALUES (?, ?)");
            $stmt->execute([$tourId, $userId]);
            return ['success' => 'Utente iscritto al tour con successo.'];
        } catch (Exception $e) {
            return ['error' => 'Impossibile iscrivere l\'utente al tour: ' . $e->getMessage()];
        }
    }
}
