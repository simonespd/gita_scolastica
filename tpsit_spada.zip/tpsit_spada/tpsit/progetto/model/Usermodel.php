<?php

class UserModel {
    private $pdo;

    public function __construct($pdo)
    {
        $this->pdo = $pdo;
    }

    // Funzione per la registrazione
    public function register($cognome, $nome, $email, $password)
    {
        // Verifica se l'email è già registrata
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM user WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetchColumn() > 0) {
            // L'email è già in uso
            return false;
        }

        // Cripta la password prima di salvarla
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        // Query per inserire un nuovo utente
        $stmt = $this->pdo->prepare("INSERT INTO user (cognome, nome, email, password) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$cognome, $nome, $email, $hashed]);
    }

    // Funzione per verificare un utente durante il login
    public function checkUser($email, $password)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM user WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // La password è corretta, ritorna l'ID dell'utente
            return $user['id'];
        }

        // Se l'utente non esiste o la password è errata
        return false;
    }

    // Funzione per il login (con gestione della sessione)
    public function loginUser($email, $password)
    {
        $userId = $this->checkUser($email, $password);
        if ($userId) {
            // Inizia la sessione e salva l'ID dell'utente
            session_start();
            $_SESSION['user_id'] = $userId;
            return true;
        }
        return false;
    }
    public function isEmailTaken($email) {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM user WHERE email = ?");
        $stmt->execute([$email]);
        return $stmt->fetchColumn() > 0;
    }
    
}
